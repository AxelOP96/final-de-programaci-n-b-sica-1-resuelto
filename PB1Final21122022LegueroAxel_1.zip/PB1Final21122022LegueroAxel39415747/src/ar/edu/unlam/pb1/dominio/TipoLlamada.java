package ar.edu.unlam.pb1.dominio;

public enum TipoLlamada {
	NACIONAL, INTERNACIONAL;
}
